var searchData=
[
  ['reconstruction_3a',['Reconstruction:',['../index.html',1,'']]],
  ['reconstruction',['Reconstruction',['../classReconstruction.html',1,'Reconstruction'],['../classReconstruction.html#a081657a94b56a22f530f6661f356906a',1,'Reconstruction::Reconstruction()'],['../classReconstruction.html#ac7ac62559b5825dcec2a760946897f40',1,'Reconstruction::Reconstruction(pcl::PointCloud&lt; pcl::PointXYZRGBNormal &gt;::Ptr &amp;, std::string)']]],
  ['reconstruction_2eh',['Reconstruction.h',['../Reconstruction_8h.html',1,'']]]
];
