var searchData=
[
  ['reconstruction_3a',['Reconstruction:',['../index.html',1,'']]]
];
